let startButton = document.getElementById('startButton');
let message = document.getElementById('message');
let timerElement = document.getElementById('timer');
let scoreElement = document.getElementById('score');
let highScoreTableBody = document.getElementById('highScoreBody');

let countdownTimer;
let reactionStartTime;
let correctKey;
let gameStarted = false;
let gameRound = 0;
let cumulativeHighScore = 0;
//let timeoutTimer; //WIP, causes problems right now <<<<<<<<<<

// Start the game
startButton.addEventListener('click', function () {
    
    if (gameStarted) return; // Avoid starting multiple games
    gameStarted = true;    
    startButton.disabled = true;
    

    if(gameRound === 0){

        message.textContent = "Get ready!";
        timerElement.textContent = "3";
        scoreElement.textContent = "";

        let countdown = 3;
        countdownTimer = setInterval(() => {
            countdown--;
            timerElement.textContent = countdown;
            if (countdown === 0) {
                clearInterval(countdownTimer);
                startReactionTest();
            }
        }, 1000);
    }
    else{
        startReactionTest();
}
});

// Start the reaction test after the countdown
function startReactionTest() {
    message.textContent = "Press the key!";
    let keys = ['W', 'A', 'S', 'D'];
    correctKey = keys[Math.floor(Math.random() * keys.length)]; // Randomly choose a key
    reactionStartTime = Date.now(); // Record the start time
    message.textContent = `Press the "${correctKey}" key!`;
    //clearTimeout(timeoutTimer); //WIP, causes problems right now <<<<<<<<<<
    // Listen for the correct key press
    window.addEventListener('keydown', keyPressListener);
}

// Listen for key press and calculate reaction time
function keyPressListener(event) {
    if (event.key.toUpperCase() === correctKey) {
        let reactionTime = Date.now() - reactionStartTime;
        let score = Math.max(0 + reactionTime, 0); // Score is based on reaction time
        cumulativeHighScore += score;
        gameRound++;

        message.textContent = `You pressed "${correctKey}"!`;
        scoreElement.textContent = `Round Score: ${score} ms\nTotal Cumulative Time: ${cumulativeHighScore}`;

        updateHighScoreTable(score);
        window.removeEventListener('keydown', keyPressListener); // Stop listening after a correct press
        
        if (cumulativeHighScore >= 20000) {
        gameover();
        return; // Stop further key presses once game ends
        }

        //clearTimeout(timeoutTimer); //WIP, causes problems right now <<<<<<<<<<
         // Start the next round immediately
        // setTimeout(() => { //WIP, causes problems right now <<<<<<<<<<
        //   gameover(); //WIP, causes problems right now <<<<<<<<<<
            
        //}, 2000); // Delay for a smooth transition between rounds (optional) //WIP, causes problems right now <<<<<<<<<<
        window.addEventListener('keydown', keyPressListener);

    startReactionTest() // Start next round immediately
    }
}
//WIP, causes problems right now <<<<<<<<<<
function gameover(){ 
    //updateHighScoreTable(2000);
    message.textContent = `Game Over! Your Final Score is ${cumulativeHighScore} milliseconds.`;
    startButton.disabled = false;
    gameStarted = false; //comment out this and the above line and add in the other line below to have it continue indefinitely
    //startReactionTest();
}

// Update the high score table
function updateHighScoreTable(score) {
    let avg = cumulativeHighScore/gameRound;
    let roundedAvg = avg.toFixed(3);
    let row = document.createElement('tr');
    row.innerHTML = `
        <td>Round ${gameRound}</td>
        <td>${score}</td>
        <td>${cumulativeHighScore}</td>
        <td>${roundedAvg}</td>
    `;
    highScoreTableBody.appendChild(row);
}
