let startButton = document.getElementById('startButton');
let message = document.getElementById('message');
let timerElement = document.getElementById('timer');
let scoreElement = document.getElementById('score');
let circle = document.getElementById('circle');
let highScoreTableBody = document.getElementById('highScoreBody');

let countdownTimer;
let gameTimer;
let reactionStartTime;
let gameStarted = false;
let gameRound = 0;
let bestTime = Infinity;

// Start the game
startButton.addEventListener('click', function () {
    if (gameStarted) return;
    gameStarted = true;
    message.textContent = "Get ready!";
    timerElement.textContent = "3";
    scoreElement.textContent = "";

    if (gameRound === 0) {

        let countdown = 3;
        countdownTimer = setInterval(() => {
            countdown--;
            timerElement.textContent = countdown;
            if (countdown === 0) {
                clearInterval(countdownTimer);
                startReactionTest();
            }
        }, 1000);
    }
    else {
        startReactionTest();
    }
});

// Start the reaction test after the countdown
function startReactionTest() {
    message.textContent = "Move your mouse!";
    showCircle();

    reactionStartTime = Date.now();
    gameTimer = setTimeout(() => {
        endGame(); // End game when 3 seconds pass
    }, 3000);
}

// Display the circle at a random position
function showCircle() {
    let screenWidth = window.innerWidth;
    let screenHeight = window.innerHeight;
    let randomX = Math.random() * (screenWidth - 50);
    let randomY = Math.random() * (screenHeight - 50);
    circle.style.left = randomX + 'px';
    circle.style.top = randomY + 'px';
    circle.style.visibility = 'visible';
}

// Listen for mouse movement to detect when the user reaches the circle
circle.addEventListener('click', function () {
    let reactionTime = Date.now() - reactionStartTime;
    let score = Math.max(5000 - reactionTime, 0);
    bestTime = Math.min(reactionTime, bestTime);

    message.textContent = "You hit the circle!";
    scoreElement.textContent = `Reaction time: ${reactionTime} ms\nScore: ${score}`;
    updateHighScoreTable(score, reactionTime);
    
    clearTimeout(gameTimer);
    gameStarted = false;
    circle.style.visibility = 'hidden';
    startReactionTest();

});

// End the game if time runs out

function endGame() {
    message.textContent = "Time's up!";
    circle.style.visibility = 'hidden';
    scoreElement.textContent = 'You did not hit the target in time!';
    updateHighScoreTable(0, Infinity);
    startButton.disabled = false;
    gameStarted = false;
}


// Update the high score table
function updateHighScoreTable(score, reactionTime) {
    let row = document.createElement('tr');
    row.innerHTML = `
        <td>Round ${gameRound + 1}</td>
        <td>${score}</td>
        <td>${reactionTime === Infinity ? 'Missed' : reactionTime + ' ms'}</td>
    `;
    highScoreTableBody.appendChild(row);
    gameRound++;
}
